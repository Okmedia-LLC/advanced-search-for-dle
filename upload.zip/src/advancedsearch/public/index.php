<?php
 
/*
=====================================================
 Advanced Search Functions - ehmedP
-----------------------------------------------------
 http://okmedia.az/
-----------------------------------------------------
 Copyright (c) 2024
=====================================================
 File: /advancedsearch/index.php
=====================================================
*/

define ( 'DATALIFEENGINE', true );
define ( 'ROOT_DIR', substr(dirname(__DIR__), 0, 27) );
define ( 'ENGINE_DIR', ROOT_DIR . '/engine' );
define ( 'ADVANCED_SERARCH_DIR', ROOT_DIR . "/advancedsearch" );

require_once(ADVANCED_SERARCH_DIR . "/modules/init.php");